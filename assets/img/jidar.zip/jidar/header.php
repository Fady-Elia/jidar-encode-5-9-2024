<?php 
include('controller/module.class.php');
$data = new ModuleClass();
$website_data = $data->get_data();
$services_data = $data->getservices();
$services_data1 = $data->getservices();
$services_count=$data->get_service_count();
$slider_data = $data->getslider();
$slider_data_slide = $data->getslider();
$current_projects=$data->get_statistics('0');
$completed_projects=$data->get_statistics('1');
$Construction_projects=$data->get_statistics('2');
$Happy_Clients=$data->get_statistics('3');
$products_data = $data->getproductslimit();

$products_cats = $data->getproducts();

$categories_data = $data->getcategories();

$why_us_data = $data->get_why_us();

$gallery_data = $data->get_gallery();
$gallery_data1 = $data->get_gallery();


if(!isset($_SESSION['language']))
{
    $_SESSION['language']="en";
}

if ( $_SESSION['language'] == "en") {
   include("lang/en.php");
} else {
   include("lang/ar.php");
}

?>
<!DOCTYPE html>
    <html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="shortcut icon" href="assets/img/logo_s.png">
        <meta charset="UTF-8">
          <title><?php $data->getTitle();?></title>
        <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
        <link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="assets/css/linearicons.css">
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="assets/css/bootstrap.css">
        <link rel="stylesheet" href="assets/css/magnific-popup.css">
        <link rel="stylesheet" href="assets/css/nice-select.css">                  
        <link rel="stylesheet" href="assets/css/animate.min.css">
        <link rel="stylesheet" href="assets/css/owl.carousel.css">
         <link rel="stylesheet" href="assets/css/main.css">

       
        <?php if ( $_SESSION['language'] == "ar") {?>
                 <link rel="stylesheet" href="assets/css/rtl.css"> 

    <?php } ?>
   
       
        <!-- <link rel="stylesheet" href="css/rtl.css"> -->

        </head>
        <body>
             <!--start header -->
              <header id="header" id="home">
                <div class="container">
                    <div class="row align-items-center justify-content-between d-flex">
                      <div id="logo">
                        <a href="index.php"><img src="assets/img/logo_s.png" class="mt-4" alt="" title="" /></a>
                      </div>
                      <nav id="nav-menu-container">
                        <ul class="nav-menu">
                              <?php $links = ['home','about','services','projects','gallery','contact'];

                                        foreach($links as $link){
                                            //to remove the second word witn space
                                            $page = strtok($pageTitle, ' ');?>
                                              <li  class="<?php echo strtolower($page) == $link ?'current':''?>">
                                            <a href="<?php echo $link == 'home' ? 'index' : $link?>.php"><?php echo lang($link);?></a></li>

                                        <?php }?>

                        <!--   <li class="menu-active"><a href="#home">Home</a></li>
                          <li><a href="about.html">About Us</a></li>
                          <li><a href="services.html">Services</a></li>
                          <li><a href="projects.html">Projects</a></li>
                          <li><a href="gallery.html">Gallery</a></li>
                          <li><a href="contact.html">Contact</a></li> -->
                          <li>
                             <div class="outer-box">
                                        <button class="search-box-btn" <?Php if ( $_SESSION['language'] == "en"){?>onclick="changelang('ar')"><span>AR</span><?php }else{ ?>onclick="changelang('en')"><span>EN</span><?php }?></button>
                                    </div>
                          
                          </li>
                        </ul>
                      </nav>                
                    </div>
                </div>
              </header>

              <!-- End header -->
